package bo;
//===========================extends SuperBo==========================
public interface ItemBo extends SuperBo{
}
