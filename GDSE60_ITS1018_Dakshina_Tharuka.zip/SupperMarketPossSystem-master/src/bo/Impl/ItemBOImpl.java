package bo.Impl;

import bo.ItemBo;
//=========================implements ItemBo=============================
public class ItemBOImpl implements ItemBo {

}
