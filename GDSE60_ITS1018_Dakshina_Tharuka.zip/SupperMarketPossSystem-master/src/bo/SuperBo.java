package bo;
//===========================Most Super======================
public interface SuperBo {
}
