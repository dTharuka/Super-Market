package dao;
//============================Most Super Interface================
public interface SuperDAO {
}
